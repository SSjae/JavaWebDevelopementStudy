use web0315;

create table spring_user (
	userid varchar(300) primary key,
    userpw varchar(300) not null,
    username varchar(300) not null
);
create table spring_board (
	boardnum bigint primary key auto_increment,
    boardtitle varchar(300) not null,
    boardcontents varchar(6000) not null,
    userid varchar(300),
    regdate datetime default now(),
    updatedate datetime default now(),
    constraint board_user_fk foreign key(userid) references spring_user(userid)
);
drop table spring_user;
drop table spring_board;

select * from spring_user;
select * from spring_board order by boardnum desc;

insert into spring_board (boardtitle, boardcontents, userid) values('테스트 제목1','apple이 작성한 테스트 내용1','apple');
insert into spring_board (boardtitle, boardcontents, userid) values('테스트 제목2','banana가 작성한 테스트 내용2','banana');
insert into spring_board (boardtitle, boardcontents, userid) values('테스트 제목3','cherry가 작성한 테스트 내용3','cherry');
insert into spring_board (boardtitle, boardcontents, userid) values('테스트 제목4','durian이 작성한 테스트 내용4','durian');

insert into spring_board (boardtitle, boardcontents, userid) (select boardtitle, boardcontents, userid from spring_board);

select * from spring_board where 0 < boardnum order by boardnum desc limit 0, 10;