package com.koreait.mapper;

import java.util.List;

import com.koreait.domain.BoardDTO;

public interface BoardMapper {
	List<BoardDTO> getList();
	void insert(BoardDTO board);
	int getMaxBoardnum(String userid);
}
