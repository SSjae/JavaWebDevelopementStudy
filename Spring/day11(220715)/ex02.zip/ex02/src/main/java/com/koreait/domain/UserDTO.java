package com.koreait.domain;

import lombok.Data;

@Data
public class UserDTO {
	private String userid;
	private String userpw;
	private String username;
}
