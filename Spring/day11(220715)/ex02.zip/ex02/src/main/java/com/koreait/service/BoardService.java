package com.koreait.service;

import java.util.List;

import com.koreait.domain.BoardDTO;

public interface BoardService {
	public List<BoardDTO> getList();
	
	public void regist(BoardDTO board);
	
	public BoardDTO get(Long boardnum);
	
	public boolean modify(BoardDTO board);
	
	public boolean remove(Long boardnum);
	
	public int getMaxBoardnum(String userid);
}
