// 여기서 따로 ajax 코드를 작성
// 선언과 동시에 실행을 시켜서 객체를 만듬
const replyService = (function() {
	function insert(reply, callback){
		$.ajax({
			type:"POST",
			url:"/reply/regist",
			data:JSON.stringify(reply), // 데이터를 제이슨으로 자동으로 바꿔서 넘겨준다.
			contentType:"application/json; charset=utf-8",
			success:function(result, status, xhr) {
				if(callback){
					callback(result);
				}
			},
			error:function() {
				
			}
		})
	}
	function selectAll(data, callback){
		let boardnum = data.boardnum;
		let pagenum = data.pagenum;
		
		// ajax
		// ajax인데 결과로 JSON을 받는 함수
		// $.getJSON(요청URI, 성공시 호출할 함수).fail(실패시 호출할 함수)
		$.getJSON(
			// 요청의 응답을 json으로 받아온다. ".json"
			"/reply/pages/"+boardnum+"/"+pagenum+".json",
			// 위의 uri의 JSON을 정상적으로 읽어왔다면 아래에 있는 함수를 호출해준다.
			// 그 때 매개변수 data에는 읽어온 json 내용이 담기게 된다.
			function(data) {
				// data : {replyCnt:댓글개수, list:[ReplyDTO, ...]}
				if(callback) {
					callback(data.replyCnt, data.list);
				}
			}
		).fail(function() {})
	}
	
	// 이제 REST에서 같은 요청이여도 요청 방식에 따라 하는 방법이 달라짐
	// GET(데이터를 가져와라), POST(데이터 추가), DELETE(삭제), PUT(수정)
	// /reply/123
	function drop(replynum, callback, error){
		$.ajax({
			type:"DELETE",
			url:"/reply/"+replynum,
			success:function(result, status, xhr) {
				if(callback){
					callback(result);
				}
			},
			error:function(xhr, status, err) {
				if(error) {
					error(err);
				}
			}
		})
	}
	// /reply/123
	function update(){}
	
	function fmtTime(reply) {
		let regdate = reply.regdate;
		let updatedate = reply.updatedate;
		const now = new Date();
		let check = regdate == updatedate;
		
		const dataObj = new Date(check?regdate:updatedate);
		// data객체.getTime() : 시간 정보를 밀리초 단위로 추출
		let gap = now.getTime() - dataObj.getTime();
		
		// gap은 밀리초로 계산 되기 때문에 1000이 1초
		let str = "";
		if(gap < 1000 * 60 * 60 * 24) {
			let hh = dataObj.getHours();
			let mi = dataObj.getMinutes();
			let ss = dataObj.getSeconds();
			
			str = (hh>9?'':'0')+hh+":"+(mi>9?'':'0')+mi+":"+(ss>9?'':'0')+ss;
		}
		else {
			let yy = dataObj.getFullYear();
			let mm = dataObj.getMonth() + 1;
			let dd = dataObj.getDate();
			
			str = yy+"/"+(mm>9?'':'0')+mm+"/"+(dd>9?'':'0')+dd;
		}
		
		return (check?'':'(수정됨) ')+str;
	}
	
	// 내부에 함수를 선언해서 외부에서는 add, getList ... 로 불러서 함수를 사용
	return {add:insert, getList:selectAll, remove:drop, modify:update, displayTime:fmtTime};
})()