package com.koreait.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
// 조건에 따른 객체
public class Criteria {
	private int pagenum;
	private int amount;
	private String type;
	private String keyword;
	private int startrow;
	
	// Spring에서 객체를 만들게 되면 무조건 기본 생성자로 만들어진다.
	public Criteria() {
		// this() : 현재 클래스의 생성자
		this(1, 10);
	}

	public Criteria(int pagenum, int amount) {
		this.pagenum = pagenum;
		this.amount = amount;
		this.startrow = 0;
	}
	
	// startrow를 pagenum이 바뀔 때마다 set을 해줌
	public void setPagenum(int pagenum) {
		this.pagenum = pagenum;
		this.startrow = (this.pagenum - 1) * this.amount;
	}
}