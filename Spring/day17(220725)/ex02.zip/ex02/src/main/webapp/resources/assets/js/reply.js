// 여기서 따로 ajax 코드를 작성
// 선언과 동시에 실행을 시켜서 객체를 만듬
const replyService = (function() {
	function insert(){}
	function selectAll(data, callback){
		let boardnum = data.boardnum;
		let pagenum = data.pagenum;
		
		// ajax
		// ajax인데 결과로 JSON을 받는 함수
		// $.getJSON(요청URI, 성공시 호출할 함수).fail(실패시 호출할 함수)
		$.getJSON(
			// 요청의 응답을 json으로 받아온다. ".json"
			"/reply/pages/"+boardnum+"/"+pagenum+".json",
			// 위의 uri의 JSON을 정상적으로 읽어왔다면 아래에 있는 함수를 호출해준다.
			// 그 때 매개변수 data에는 읽어온 json 내용이 담기게 된다.
			function(data) {
				// data : {replyCnt:댓글개수, list:[ReplyDTO, ...]}
				if(callback) {
					callback(data.replyCnt, reply.list);
				}
			}
		).fail(function() {})
	}
	function drop(){}
	function update(){}
	
	// 내부에 함수를 선언해서 외부에서는 add, getList ... 로 불러서 함수를 사용
	return {add:insert, getList:selectAll, remove:drop, modify:update};
})()