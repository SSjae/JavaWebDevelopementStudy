package com.koreait.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.koreait.service.ReplyService;

import lombok.Setter;

@RequestMapping("/reply/*")
// Rest 방식에 컨트롤러이다.
@RestController
public class ReplyController {
	@Setter(onMethod_ = @Autowired)
	private ReplyService service;
	
}
