package com.koreait.domain;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
// 조건에 따른 객체
public class Criteria {
	private int pagenum;
	private int amount;
	private String type;
	private String keyword;
	private int startrow;
	
	// Spring에서 객체를 만들게 되면 무조건 기본 생성자로 만들어진다.
	public Criteria() {
		// this() : 현재 클래스의 생성자
		this(1, 10);
	}

	public Criteria(int pagenum, int amount) {
		this.pagenum = pagenum;
		this.amount = amount;
		this.startrow = 0;
	}
	
	// startrow를 pagenum이 바뀔 때마다 set을 해줌
	public void setPagenum(int pagenum) {
		this.pagenum = pagenum;
		this.startrow = (this.pagenum - 1) * this.amount;
	}
	
	public String[] getTypeArr() {
		// type이 null이라면 return {}
		// type에 "TC"가 있다면 return {"T", "C"}
		return type == null ? new String[] {} : type.split("");
	}
	
	public String getListLink() {
		// 나중에 파라미터들을 하나하나 우리가 추가해주는 것보다 빌더를 만드는 것이 더 좋음
		UriComponentsBuilder builder = UriComponentsBuilder.fromPath("")	// ? 앞에 오는 uri 문자열
				.queryParam("pagenum", pagenum)								// 파라미터 추가
				.queryParam("amount", amount)
				.queryParam("keyword", keyword)
				.queryParam("type", type);
		
		// ?pagenum=3&amount=10&keyword=app&type=TC
		return builder.toUriString();										// 빌더가 가지고 있는 설정대로 문자열 만들기
	}
}